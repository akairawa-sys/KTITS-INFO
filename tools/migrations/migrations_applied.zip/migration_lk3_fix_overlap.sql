-- lk3 нижний ряд: исправление наложений
SET NAMES utf8mb4;
UPDATE rooms SET x = 40, w = 46 WHERE floor_id = 8 AND room_key = 'stairs-w';
UPDATE rooms SET x = 98, w = 152 WHERE floor_id = 8 AND room_key = '1318';
UPDATE rooms SET x = 262, w = 152 WHERE floor_id = 8 AND room_key = '1316';
UPDATE rooms SET x = 426, w = 114 WHERE floor_id = 8 AND room_key = '1314';
UPDATE rooms SET x = 552, w = 116 WHERE floor_id = 8 AND room_key = '1312';
UPDATE rooms SET x = 680, w = 73 WHERE floor_id = 8 AND room_key = 'teachers';
UPDATE rooms SET x = 765, w = 57 WHERE floor_id = 8 AND room_key = 'wc-m';
UPDATE rooms SET x = 834, w = 57 WHERE floor_id = 8 AND room_key = 'wc-f';
UPDATE rooms SET x = 903, w = 133 WHERE floor_id = 8 AND room_key = '1304';
UPDATE rooms SET x = 1048, w = 152 WHERE floor_id = 8 AND room_key = '1302';
