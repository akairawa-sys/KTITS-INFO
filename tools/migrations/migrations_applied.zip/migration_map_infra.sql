-- Подложки этажей и маршрутная сеть. Выполнить один раз на существующей базе.
SET NAMES utf8mb4;
USE `ktits_info`;

ALTER TABLE `floors`
  ADD COLUMN `underlay_path` VARCHAR(255) NOT NULL DEFAULT '' AFTER `title`,
  ADD COLUMN `underlay_opacity` DECIMAL(3,2) NOT NULL DEFAULT 0.35 AFTER `underlay_path`,
  ADD COLUMN `underlay_scale` DECIMAL(5,2) NOT NULL DEFAULT 1.00 AFTER `underlay_opacity`;

CREATE TABLE IF NOT EXISTS `route_nodes` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `floor_id` SMALLINT UNSIGNED NOT NULL,
  `x` SMALLINT UNSIGNED NOT NULL,
  `y` SMALLINT UNSIGNED NOT NULL,
  `kind` ENUM('corridor','entrance','stairs','passage') NOT NULL DEFAULT 'corridor',
  `room_key` VARCHAR(100) NULL,
  PRIMARY KEY (`id`),
  KEY `ix_route_nodes_floor` (`floor_id`),
  KEY `ix_route_nodes_connection` (`kind`,`room_key`),
  CONSTRAINT `fk_route_nodes_floor` FOREIGN KEY (`floor_id`) REFERENCES `floors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `route_edges` (
  `node_a` INT UNSIGNED NOT NULL,
  `node_b` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`node_a`,`node_b`),
  KEY `ix_route_edges_node_b` (`node_b`),
  CONSTRAINT `fk_route_edges_a` FOREIGN KEY (`node_a`) REFERENCES `route_nodes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_route_edges_b` FOREIGN KEY (`node_b`) REFERENCES `route_nodes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Перенос строчной раскладки в координаты 1:1 с прежней функцией arrangedRooms().
UPDATE `rooms` AS `r`
JOIN (
  SELECT `id`, `row_y`, `row_height`, `weight`, `previous_weight`, `position`, `room_count`, `total_weight`
  FROM (
    SELECT
      `id`, `row_y`, `row_height`,
      COALESCE(`weight`, 1) AS `weight`,
      ROW_NUMBER() OVER (PARTITION BY `floor_id`, `row_index` ORDER BY `sort_order`, `id`) AS `position`,
      COUNT(*) OVER (PARTITION BY `floor_id`, `row_index`) AS `room_count`,
      SUM(COALESCE(`weight`, 1)) OVER (PARTITION BY `floor_id`, `row_index`) AS `total_weight`,
      COALESCE(
        SUM(COALESCE(`weight`, 1)) OVER (
          PARTITION BY `floor_id`, `row_index` ORDER BY `sort_order`, `id`
          ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING
        ),
        0
      ) AS `previous_weight`
    FROM `rooms`
    WHERE `row_index` IS NOT NULL
  ) AS `ranked`
) AS `c` ON `c`.`id` = `r`.`id`
SET
  `r`.`x` = ROUND(40 + `c`.`previous_weight` * ((1160 - 12 * (`c`.`room_count` - 1)) / `c`.`total_weight`) + 12 * (`c`.`position` - 1)),
  `r`.`y` = `c`.`row_y`,
  `r`.`w` = ROUND(`c`.`weight` * ((1160 - 12 * (`c`.`room_count` - 1)) / `c`.`total_weight`)),
  `r`.`h` = `c`.`row_height`,
  `r`.`row_index` = NULL,
  `r`.`row_y` = NULL,
  `r`.`row_height` = NULL,
  `r`.`weight` = NULL;

-- Демонстрационная сеть только для первого этажа учебного корпуса.
INSERT INTO `route_nodes` (`id`, `floor_id`, `x`, `y`, `kind`, `room_key`) VALUES
  (1, 1, 170, 360, 'corridor', NULL),
  (2, 1, 320, 360, 'corridor', NULL),
  (3, 1, 470, 360, 'corridor', NULL),
  (4, 1, 620, 360, 'corridor', NULL),
  (5, 1, 770, 360, 'corridor', NULL),
  (6, 1, 920, 360, 'corridor', NULL),
  (7, 1, 1070, 360, 'corridor', NULL),
  (8, 1, 620, 600, 'entrance', 'entrance'),
  (9, 1, 380, 190, 'stairs', 'stairs-w'),
  (10, 1, 1145, 450, 'passage', 'pass-lk');

INSERT INTO `route_edges` (`node_a`, `node_b`) VALUES
  (1, 2), (2, 3), (3, 4), (4, 5), (5, 6), (6, 7),
  (4, 8), (2, 9), (7, 10);
