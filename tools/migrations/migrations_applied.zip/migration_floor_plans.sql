-- Правки по ответам заказчика (ноябрь 2026):
-- спортзал остаётся на 1ЛК; 303/224/209 не добавляем; серверные не добавляем;
-- «Белый зал» -> «Актовый зал»; 422b удалён; тёплый переход — в середине УК1 (по фото);
-- подложки этажей из фото планов эвакуации.
SET NAMES utf8mb4;

-- УК1: Белый зал -> Актовый зал
UPDATE rooms SET name = 'Актовый зал' WHERE floor_id = 1 AND room_key = 'white';

-- УК1: тёплый переход в ЛК — в середине этажа (отмечен заказчиком на фото)
UPDATE rooms SET x = 560, y = 60, w = 150, h = 120 WHERE floor_id = 1 AND room_key = 'pass-lk';

-- УК4: 422b убран (в БД остаётся только 422)
DELETE FROM rooms WHERE floor_id = 4 AND room_key = '422b';

-- Маршрутный граф uk1: узел тёплого перехода перенесён в середину этажа
UPDATE route_nodes SET x = 635, y = 120 WHERE kind = 'passage' AND room_key = 'pass-lk';
DELETE FROM route_edges
WHERE (node_a = 7 AND node_b = (SELECT id FROM route_nodes WHERE kind = 'passage' AND room_key = 'pass-lk'))
   OR (node_b = 7 AND node_a = (SELECT id FROM route_nodes WHERE kind = 'passage' AND room_key = 'pass-lk'));
INSERT INTO route_edges (node_a, node_b)
SELECT 4, id FROM route_nodes WHERE kind = 'passage' AND room_key = 'pass-lk'
  AND NOT EXISTS (
    SELECT 1 FROM route_edges e
    WHERE (e.node_a = 4 AND e.node_b = route_nodes.id) OR (e.node_b = 4 AND e.node_a = route_nodes.id)
  );

-- Подложки этажей из фото планов эвакуации
UPDATE floors SET underlay_path = 'uploads/floors/uk1.jpg', underlay_opacity = 0.35, underlay_scale = 1.00 WHERE floor_key = 'uk1';
UPDATE floors SET underlay_path = 'uploads/floors/uk2.jpg', underlay_opacity = 0.35, underlay_scale = 1.00 WHERE floor_key = 'uk2';
UPDATE floors SET underlay_path = 'uploads/floors/uk3.jpg', underlay_opacity = 0.35, underlay_scale = 1.00 WHERE floor_key = 'uk3';
UPDATE floors SET underlay_path = 'uploads/floors/uk4.jpg', underlay_opacity = 0.35, underlay_scale = 1.00 WHERE floor_key = 'uk4';
UPDATE floors SET underlay_path = 'uploads/floors/lk1.jpg', underlay_opacity = 0.35, underlay_scale = 1.00 WHERE floor_key = 'lk1';
UPDATE floors SET underlay_path = 'uploads/floors/lk2.jpg', underlay_opacity = 0.35, underlay_scale = 1.00 WHERE floor_key = 'lk2';
UPDATE floors SET underlay_path = 'uploads/floors/lk3.jpg', underlay_opacity = 0.35, underlay_scale = 1.00 WHERE floor_key = 'lk3';
