-- lk3 нижний ряд: зазор 12px
SET NAMES utf8mb4;
UPDATE rooms SET x = 40, w = 51 WHERE floor_id = 8 AND room_key = 'stairs-w';
UPDATE rooms SET x = 103, w = 169 WHERE floor_id = 8 AND room_key = '1318';
UPDATE rooms SET x = 284, w = 169 WHERE floor_id = 8 AND room_key = '1316';
UPDATE rooms SET x = 465, w = 127 WHERE floor_id = 8 AND room_key = '1314';
UPDATE rooms SET x = 604, w = 106 WHERE floor_id = 8 AND room_key = '1310';
UPDATE rooms SET x = 722, w = 63 WHERE floor_id = 8 AND room_key = 'wc-m';
UPDATE rooms SET x = 797, w = 63 WHERE floor_id = 8 AND room_key = 'wc-f';
UPDATE rooms SET x = 872, w = 148 WHERE floor_id = 8 AND room_key = '1304';
UPDATE rooms SET x = 1032, w = 169 WHERE floor_id = 8 AND room_key = '1302';
