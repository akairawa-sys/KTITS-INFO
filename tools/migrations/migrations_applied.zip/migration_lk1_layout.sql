-- ЛК 1 этаж: расстановка по списку заказчика
SET NAMES utf8mb4;
DELETE FROM rooms WHERE floor_id = 6;
INSERT INTO rooms (floor_id, room_key, name, type, row_index, row_y, row_height, weight, x, y, w, h, sort_order) VALUES (6, 'wc-m', 'Мужской туалет', 'service', NULL, NULL, NULL, NULL, 40, 210, 65, 100, 1);
INSERT INTO rooms (floor_id, room_key, name, type, row_index, row_y, row_height, weight, x, y, w, h, sort_order) VALUES (6, 'wc-f', 'Женский туалет', 'service', NULL, NULL, NULL, NULL, 117, 210, 65, 100, 2);
INSERT INTO rooms (floor_id, room_key, name, type, row_index, row_y, row_height, weight, x, y, w, h, sort_order) VALUES (6, 'med-procedure', 'Процедурный кабинет', 'service', NULL, NULL, NULL, NULL, 194, 210, 175, 100, 3);
INSERT INTO rooms (floor_id, room_key, name, type, row_index, row_y, row_height, weight, x, y, w, h, sort_order) VALUES (6, '1120', 'Аудитория 1120', 'aud', NULL, NULL, NULL, NULL, 381, 210, 175, 100, 4);
INSERT INTO rooms (floor_id, room_key, name, type, row_index, row_y, row_height, weight, x, y, w, h, sort_order) VALUES (6, '1122', 'Аудитория 1122', 'aud', NULL, NULL, NULL, NULL, 568, 210, 175, 100, 5);
INSERT INTO rooms (floor_id, room_key, name, type, row_index, row_y, row_height, weight, x, y, w, h, sort_order) VALUES (6, '1124', 'Аудитория 1124', 'aud', NULL, NULL, NULL, NULL, 755, 210, 175, 100, 6);
INSERT INTO rooms (floor_id, room_key, name, type, row_index, row_y, row_height, weight, x, y, w, h, sort_order) VALUES (6, '1126', 'Аудитория 1126', 'aud', NULL, NULL, NULL, NULL, 942, 210, 175, 100, 7);
INSERT INTO rooms (floor_id, room_key, name, type, row_index, row_y, row_height, weight, x, y, w, h, sort_order) VALUES (6, 'stairs-e', 'Лестница', 'stairs', NULL, NULL, NULL, NULL, 1129, 210, 71, 100, 8);
INSERT INTO rooms (floor_id, room_key, name, type, row_index, row_y, row_height, weight, x, y, w, h, sort_order) VALUES (6, 'pass-uk', 'Переход в учебный корпус', 'service', NULL, NULL, NULL, NULL, 40, 410, 86, 100, 1);
INSERT INTO rooms (floor_id, room_key, name, type, row_index, row_y, row_height, weight, x, y, w, h, sort_order) VALUES (6, '1117', 'Малая переговорная', 'service', NULL, NULL, NULL, NULL, 138, 410, 193, 100, 2);
INSERT INTO rooms (floor_id, room_key, name, type, row_index, row_y, row_height, weight, x, y, w, h, sort_order) VALUES (6, '1119', 'Аудитория 1119', 'aud', NULL, NULL, NULL, NULL, 343, 410, 193, 100, 3);
INSERT INTO rooms (floor_id, room_key, name, type, row_index, row_y, row_height, weight, x, y, w, h, sort_order) VALUES (6, '1121', 'Аудитория 1121', 'aud', NULL, NULL, NULL, NULL, 548, 410, 193, 100, 4);
INSERT INTO rooms (floor_id, room_key, name, type, row_index, row_y, row_height, weight, x, y, w, h, sort_order) VALUES (6, '1125-1127', 'Аудитории 1125–1127 (объединены)', 'aud', NULL, NULL, NULL, NULL, 753, 410, 243, 100, 5);
INSERT INTO rooms (floor_id, room_key, name, type, row_index, row_y, row_height, weight, x, y, w, h, sort_order) VALUES (6, '1129', 'Аудитория 1129', 'aud', NULL, NULL, NULL, NULL, 1008, 410, 193, 100, 6);
DELETE FROM route_nodes WHERE floor_id = 6;
DELETE FROM route_edges WHERE node_a IN (SELECT id FROM route_nodes WHERE floor_id = 6);
