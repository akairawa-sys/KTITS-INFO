-- lk3 нижний ряд: воздух между помещениями (уменьшение + зазоры)
SET NAMES utf8mb4;
UPDATE rooms SET x = 40, w = 39 WHERE floor_id = 8 AND room_key = 'stairs-w';
UPDATE rooms SET x = 103, w = 129 WHERE floor_id = 8 AND room_key = '1318';
UPDATE rooms SET x = 256, w = 129 WHERE floor_id = 8 AND room_key = '1316';
UPDATE rooms SET x = 409, w = 97 WHERE floor_id = 8 AND room_key = '1314';
UPDATE rooms SET x = 530, w = 129 WHERE floor_id = 8 AND room_key = '1312';
UPDATE rooms SET x = 683, w = 81 WHERE floor_id = 8 AND room_key = 'teachers';
UPDATE rooms SET x = 788, w = 48 WHERE floor_id = 8 AND room_key = 'wc-m';
UPDATE rooms SET x = 860, w = 48 WHERE floor_id = 8 AND room_key = 'wc-f';
UPDATE rooms SET x = 932, w = 113 WHERE floor_id = 8 AND room_key = '1304';
UPDATE rooms SET x = 1069, w = 129 WHERE floor_id = 8 AND room_key = '1302';
