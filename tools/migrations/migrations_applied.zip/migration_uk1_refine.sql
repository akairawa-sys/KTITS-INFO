-- УК1: правки по макету — стены, больше площади помещений, без наложений
SET NAMES utf8mb4;
UPDATE rooms SET x = 40, y = 280, w = 240, h = 360 WHERE floor_id = 1 AND room_key = 'conf';
UPDATE rooms SET x = 300, y = 180, w = 220, h = 140 WHERE floor_id = 1 AND room_key = 'stolovaya';
UPDATE rooms SET x = 532, y = 180, w = 70, h = 140 WHERE floor_id = 1 AND room_key = 'stairs-w';
UPDATE rooms SET x = 760, y = 30, w = 80, h = 170 WHERE floor_id = 1 AND room_key = 'pass-lk';
UPDATE rooms SET x = 940, y = 180, w = 260, h = 340 WHERE floor_id = 1 AND room_key = 'lib';
UPDATE rooms SET x = 800, y = 400, w = 130, h = 120 WHERE floor_id = 1 AND room_key = 'white';
UPDATE rooms SET x = 680, y = 400, w = 100, h = 120 WHERE floor_id = 1 AND room_key = 'garderob';
UPDATE rooms SET x = 620, y = 320, w = 70, h = 45 WHERE floor_id = 1 AND room_key = 'kiosk';
UPDATE rooms SET x = 490, y = 450, w = 90, h = 90 WHERE floor_id = 1 AND room_key = 'entrance';
UPDATE rooms SET x = 590, y = 450, w = 70, h = 90 WHERE floor_id = 1 AND room_key = 'ohrana';
