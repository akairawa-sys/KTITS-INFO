-- Читаемость карты: устранение наложений, спортзал меньше, спортзал в составе ЛК
SET NAMES utf8mb4;

-- Спортзал относится к Лабораторному корпусу
UPDATE floors SET floor_key = 'lk1s' WHERE floor_key = 'uk1s';

-- uk1: убираем наложения лестницы/столовой/киоска/охраны
UPDATE rooms SET x = 497, y = 280, w = 66, h = 110 WHERE floor_id = 1 AND room_key = 'stairs-w';
UPDATE rooms SET x = 570, y = 400, w = 44, h = 30 WHERE floor_id = 1 AND room_key = 'kiosk';
UPDATE rooms SET x = 620, y = 430, w = 70, h = 29 WHERE floor_id = 1 AND room_key = 'ohrana';

-- uk2: музей не должен перекрывать 203/205
UPDATE rooms SET x = 975, y = 284, w = 245, h = 195 WHERE floor_id = 2 AND room_key = 'museum';
UPDATE rooms SET w = 110 WHERE floor_id = 2 AND room_key = '205';

-- Спортивный зал меньше — место для остальных элементов спортзала
UPDATE rooms SET x = 640, y = 200, w = 543, h = 320 WHERE floor_id = 5 AND room_key = 'sport';
