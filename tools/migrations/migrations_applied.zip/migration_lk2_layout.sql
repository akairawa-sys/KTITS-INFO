-- ЛК 2 этаж: компоновка по образцу 3-го (чётные/нечётные стороны), маршрутные сети lk2/lk3 пересобраны
SET NAMES utf8mb4;

-- Удаляем старые помещения 2 этажа ЛК (лаборатории и прочие) — остаются только номерные аудитории,
-- санузлы и лестницы по списку заказчика
DELETE FROM rooms WHERE floor_id = 7;

INSERT INTO rooms (floor_id, room_key, name, type, row_index, row_y, row_height, weight, x, y, w, h, sort_order) VALUES
(7, '1201', 'Аудитория 1201', 'aud', NULL, NULL, NULL, NULL, 40, 210, 124, 100, 1),
(7, '1203', 'Аудитория 1203', 'aud', NULL, NULL, NULL, NULL, 178, 210, 124, 100, 2),
(7, 'stairs-e', 'Лестница', 'stairs', NULL, NULL, NULL, NULL, 316, 210, 70, 100, 3),
(7, '1207-1209', 'Аудитории 1207–1209 (объединены)', 'aud', NULL, NULL, NULL, NULL, 400, 210, 176, 100, 4),
(7, '1211', 'ЦИТиП', 'service', NULL, NULL, NULL, NULL, 590, 210, 124, 100, 5),
(7, '1213', 'Начальник ЦИТиП', 'service', NULL, NULL, NULL, NULL, 728, 210, 124, 100, 6),
(7, '1215', 'Аудитория 1215', 'aud', NULL, NULL, NULL, NULL, 866, 210, 124, 100, 7),
(7, '1217', 'Аудитория 1217', 'aud', NULL, NULL, NULL, NULL, 1004, 210, 124, 100, 8),
(7, '1219', 'Аудитория 1219', 'aud', NULL, NULL, NULL, NULL, 1142, 210, 58, 100, 9),
(7, '1202', 'Аудитория 1202', 'aud', NULL, NULL, NULL, NULL, 40, 410, 106, 100, 1),
(7, '1204', 'Учебный центр', 'service', NULL, NULL, NULL, NULL, 160, 410, 106, 100, 2),
(7, 'wc-m', 'Мужской туалет', 'service', NULL, NULL, NULL, NULL, 280, 410, 55, 100, 3),
(7, 'wc-f', 'Женский туалет', 'service', NULL, NULL, NULL, NULL, 347, 410, 55, 100, 4),
(7, '1210', 'Аудитория 1210', 'aud', NULL, NULL, NULL, NULL, 416, 410, 106, 100, 5),
(7, '1212', 'Зав. учебной практикой · Центр карьеры', 'service', NULL, NULL, NULL, NULL, 536, 410, 106, 100, 6),
(7, '1214', 'Руководитель учебного центра', 'service', NULL, NULL, NULL, NULL, 656, 410, 106, 100, 7),
(7, '1216', 'Преподавательская', 'service', NULL, NULL, NULL, NULL, 776, 410, 106, 100, 8),
(7, '1218', 'Аудитория 1218', 'aud', NULL, NULL, NULL, NULL, 896, 410, 106, 100, 9),
(7, '1220', 'Аудитория 1220', 'aud', NULL, NULL, NULL, NULL, 1016, 410, 106, 100, 10),
(7, 'stairs-w', 'Лестница', 'stairs', NULL, NULL, NULL, NULL, 1134, 410, 66, 100, 11);
