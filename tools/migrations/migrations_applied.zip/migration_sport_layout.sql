-- Спортзал (lk1s): переход слева вверху вытянутый, тренажерная+венткамера+кладовая за ним,
-- нижний ряд от границы перехода, спортзал по ширине этажа
SET NAMES utf8mb4;
DELETE FROM rooms WHERE floor_id = 5;
INSERT INTO rooms (floor_id, room_key, name, type, row_index, row_y, row_height, weight, x, y, w, h, sort_order) VALUES
(5, 'pass-uk', 'Переход в учебный корпус', 'service', NULL, NULL, NULL, NULL, 30, 60, 80, 340, 1),
(5, 'trainers', 'Комната тренажеров', 'service', NULL, NULL, NULL, NULL, 122, 60, 180, 150, 2),
(5, 'vent', 'Венткамера', 'service', NULL, NULL, NULL, NULL, 314, 60, 80, 150, 3),
(5, 'inventory', 'Кладовая спортинвентаря', 'service', NULL, NULL, NULL, NULL, 406, 60, 180, 150, 4),
(5, 'sport', 'Спортивный зал', 'service', NULL, NULL, NULL, NULL, 600, 60, 600, 320, 5),
(5, 'pe-head', 'Кабинет руководителя физической культуры', 'service', NULL, NULL, NULL, NULL, 110, 430, 180, 150, 6),
(5, 'pe-staff', 'Преподавательская физкультуры', 'service', NULL, NULL, NULL, NULL, 302, 430, 180, 150, 7),
(5, 'changing-m', 'Раздевалка мужская', 'service', NULL, NULL, NULL, NULL, 494, 430, 150, 150, 8),
(5, 'changing-f', 'Раздевалка женская', 'service', NULL, NULL, NULL, NULL, 656, 430, 150, 150, 9);
DELETE FROM route_nodes WHERE floor_id = 5;
DELETE FROM route_edges WHERE node_a IN (SELECT id FROM route_nodes WHERE floor_id = 5);
