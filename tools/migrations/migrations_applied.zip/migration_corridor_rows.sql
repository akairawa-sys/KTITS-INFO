-- Раздвигаем ряды помещений: коридор 310..430 виден на всех этажах
SET NAMES utf8mb4;

UPDATE rooms SET y = 233 WHERE id = 11; -- uk2/232
UPDATE rooms SET y = 233 WHERE id = 12; -- uk2/230
UPDATE rooms SET y = 213 WHERE id = 13; -- uk2/224
UPDATE rooms SET y = 213 WHERE id = 14; -- uk2/222
UPDATE rooms SET y = 213 WHERE id = 15; -- uk2/wc-m
UPDATE rooms SET y = 213 WHERE id = 16; -- uk2/wc-f
UPDATE rooms SET y = 183 WHERE id = 17; -- uk2/stairs-w
UPDATE rooms SET y = 235 WHERE id = 18; -- uk2/214
UPDATE rooms SET y = 235 WHERE id = 19; -- uk2/212
UPDATE rooms SET y = 235 WHERE id = 20; -- uk2/server
UPDATE rooms SET y = 235 WHERE id = 21; -- uk2/208
UPDATE rooms SET y = 235 WHERE id = 22; -- uk2/206
UPDATE rooms SET y = 235 WHERE id = 23; -- uk2/204
UPDATE rooms SET y = 235 WHERE id = 24; -- uk2/202
UPDATE rooms SET y = 430 WHERE id = 25; -- uk2/museum
UPDATE rooms SET y = 430 WHERE id = 26; -- uk2/227
UPDATE rooms SET y = 430 WHERE id = 27; -- uk2/225
UPDATE rooms SET y = 430 WHERE id = 28; -- uk2/223
UPDATE rooms SET y = 430 WHERE id = 29; -- uk2/221
UPDATE rooms SET y = 430 WHERE id = 30; -- uk2/215
UPDATE rooms SET y = 430 WHERE id = 31; -- uk2/213
UPDATE rooms SET y = 430 WHERE id = 32; -- uk2/211
UPDATE rooms SET y = 430 WHERE id = 33; -- uk2/209
UPDATE rooms SET y = 430 WHERE id = 34; -- uk2/207
UPDATE rooms SET y = 430 WHERE id = 35; -- uk2/205
UPDATE rooms SET y = 430 WHERE id = 36; -- uk2/203
UPDATE rooms SET y = 236 WHERE id = 37; -- uk3/324
UPDATE rooms SET y = 218 WHERE id = 38; -- uk3/322
UPDATE rooms SET y = 218 WHERE id = 39; -- uk3/wc-m
UPDATE rooms SET y = 218 WHERE id = 40; -- uk3/wc-f
UPDATE rooms SET y = 190 WHERE id = 41; -- uk3/stairs-w
UPDATE rooms SET y = 227 WHERE id = 42; -- uk3/314
UPDATE rooms SET y = 227 WHERE id = 43; -- uk3/server
UPDATE rooms SET y = 229 WHERE id = 44; -- uk3/310
UPDATE rooms SET y = 229 WHERE id = 45; -- uk3/308
UPDATE rooms SET y = 237 WHERE id = 46; -- uk3/304
UPDATE rooms SET y = 237 WHERE id = 47; -- uk3/302
UPDATE rooms SET y = 211 WHERE id = 48; -- uk3/stairs-e
UPDATE rooms SET y = 430 WHERE id = 49; -- uk3/321
UPDATE rooms SET y = 430 WHERE id = 50; -- uk3/319
UPDATE rooms SET y = 430 WHERE id = 51; -- uk3/315
UPDATE rooms SET y = 430 WHERE id = 52; -- uk3/313
UPDATE rooms SET y = 430 WHERE id = 53; -- uk3/311
UPDATE rooms SET y = 430 WHERE id = 54; -- uk3/309
UPDATE rooms SET y = 430 WHERE id = 55; -- uk3/307
UPDATE rooms SET y = 430 WHERE id = 56; -- uk3/305
UPDATE rooms SET y = 430 WHERE id = 57; -- uk3/303
UPDATE rooms SET y = 430 WHERE id = 58; -- uk3/301
UPDATE rooms SET y = 235 WHERE id = 59; -- uk4/426
UPDATE rooms SET y = 235 WHERE id = 60; -- uk4/424
UPDATE rooms SET y = 235 WHERE id = 61; -- uk4/422
UPDATE rooms SET y = 235 WHERE id = 62; -- uk4/wc-m
UPDATE rooms SET y = 235 WHERE id = 63; -- uk4/wc-f
UPDATE rooms SET y = 189 WHERE id = 64; -- uk4/stairs-w
UPDATE rooms SET y = 238 WHERE id = 65; -- uk4/416
UPDATE rooms SET y = 238 WHERE id = 66; -- uk4/414
UPDATE rooms SET y = 238 WHERE id = 67; -- uk4/server
UPDATE rooms SET y = 238 WHERE id = 68; -- uk4/410
UPDATE rooms SET y = 238 WHERE id = 69; -- uk4/408
UPDATE rooms SET y = 238 WHERE id = 70; -- uk4/406
UPDATE rooms SET y = 238 WHERE id = 71; -- uk4/404
UPDATE rooms SET y = 238 WHERE id = 72; -- uk4/402
UPDATE rooms SET y = 207 WHERE id = 73; -- uk4/stairs-e
UPDATE rooms SET y = 430 WHERE id = 74; -- uk4/425
UPDATE rooms SET y = 430 WHERE id = 75; -- uk4/423
UPDATE rooms SET y = 430 WHERE id = 76; -- uk4/419
UPDATE rooms SET y = 430 WHERE id = 77; -- uk4/417
UPDATE rooms SET y = 430 WHERE id = 78; -- uk4/413
UPDATE rooms SET y = 430 WHERE id = 79; -- uk4/411
UPDATE rooms SET y = 430 WHERE id = 80; -- uk4/409
UPDATE rooms SET y = 430 WHERE id = 81; -- uk4/407
UPDATE rooms SET y = 430 WHERE id = 82; -- uk4/405
UPDATE rooms SET y = 430 WHERE id = 83; -- uk4/403
UPDATE rooms SET y = 430 WHERE id = 84; -- uk4/401
UPDATE rooms SET y = 189 WHERE id = 94; -- lk1/wc-f
UPDATE rooms SET y = 189 WHERE id = 95; -- lk1/wc-m
UPDATE rooms SET y = 248 WHERE id = 96; -- lk1/med-procedure
UPDATE rooms SET y = 194 WHERE id = 97; -- lk1/med-doctor
UPDATE rooms SET y = 194 WHERE id = 98; -- lk1/lk1-cab-n1
UPDATE rooms SET y = 194 WHERE id = 99; -- lk1/lk1-cab-n2
UPDATE rooms SET y = 199 WHERE id = 100; -- lk1/lk1-study-n1
UPDATE rooms SET y = 191 WHERE id = 101; -- lk1/lk1-study-n2
UPDATE rooms SET y = 194 WHERE id = 102; -- lk1/lk1-study-n3
UPDATE rooms SET y = 199 WHERE id = 103; -- lk1/stairs-e
UPDATE rooms SET y = 430 WHERE id = 104; -- lk1/pass-uk
UPDATE rooms SET y = 430 WHERE id = 105; -- lk1/heat-node
UPDATE rooms SET y = 430 WHERE id = 106; -- lk1/electrical
UPDATE rooms SET y = 430 WHERE id = 107; -- lk1/negotiation
UPDATE rooms SET y = 430 WHERE id = 108; -- lk1/psych-relax
UPDATE rooms SET y = 430 WHERE id = 109; -- lk1/psychologist
UPDATE rooms SET y = 430 WHERE id = 111; -- lk1/lab-access-1
UPDATE rooms SET y = 430 WHERE id = 112; -- lk1/lab-access-2
UPDATE rooms SET y = 430 WHERE id = 113; -- lk1/lk1-study-s1
UPDATE rooms SET y = 222 WHERE id = 114; -- lk2/studio
UPDATE rooms SET y = 219 WHERE id = 115; -- lk2/lab-broadcast
UPDATE rooms SET y = 226 WHERE id = 116; -- lk2/montage
UPDATE rooms SET y = 224 WHERE id = 117; -- lk2/asup-head
UPDATE rooms SET y = 224 WHERE id = 118; -- lk2/server
UPDATE rooms SET y = 227 WHERE id = 119; -- lk2/asup
UPDATE rooms SET y = 224 WHERE id = 120; -- lk2/tattelecom-1
UPDATE rooms SET y = 224 WHERE id = 121; -- lk2/tattelecom-2
UPDATE rooms SET y = 227 WHERE id = 122; -- lk2/wc-m
UPDATE rooms SET y = 225 WHERE id = 123; -- lk2/stairs-e
UPDATE rooms SET y = 220 WHERE id = 124; -- lk2/lab-subscriber
UPDATE rooms SET y = 220 WHERE id = 125; -- lk2/lab-telecom
UPDATE rooms SET y = 430 WHERE id = 126; -- lk2/stairs-w
UPDATE rooms SET y = 430 WHERE id = 127; -- lk2/lab-mobile
UPDATE rooms SET y = 430 WHERE id = 128; -- lk2/electro-montage
UPDATE rooms SET y = 430 WHERE id = 129; -- lk2/lab-directional
UPDATE rooms SET y = 430 WHERE id = 130; -- lk2/lk2-cab-s1
UPDATE rooms SET y = 430 WHERE id = 131; -- lk2/lk2-cab-s2
UPDATE rooms SET y = 430 WHERE id = 132; -- lk2/lab-radio
UPDATE rooms SET y = 430 WHERE id = 133; -- lk2/wc-f
UPDATE rooms SET y = 430 WHERE id = 134; -- lk2/teachers
UPDATE rooms SET y = 430 WHERE id = 135; -- lk2/lab-power
UPDATE rooms SET y = 430 WHERE id = 136; -- lk2/ats
UPDATE rooms SET y = 218 WHERE id = 137; -- lk3/archive
UPDATE rooms SET y = 218 WHERE id = 138; -- lk3/lk3-study-n1
UPDATE rooms SET y = 221 WHERE id = 139; -- lk3/lk3-study-n2
UPDATE rooms SET y = 221 WHERE id = 140; -- lk3/lk3-study-n3
UPDATE rooms SET y = 221 WHERE id = 141; -- lk3/server
UPDATE rooms SET y = 223 WHERE id = 142; -- lk3/lk3-study-n4
UPDATE rooms SET y = 223 WHERE id = 143; -- lk3/lk3-study-n5
UPDATE rooms SET y = 180 WHERE id = 144; -- lk3/stairs-e
UPDATE rooms SET y = 221 WHERE id = 145; -- lk3/lk3-study-n6
UPDATE rooms SET y = 221 WHERE id = 146; -- lk3/network-workshop
UPDATE rooms SET y = 430 WHERE id = 147; -- lk3/stairs-w
UPDATE rooms SET y = 430 WHERE id = 148; -- lk3/lk3-study-s1
UPDATE rooms SET y = 430 WHERE id = 149; -- lk3/lk3-study-s2
UPDATE rooms SET y = 430 WHERE id = 150; -- lk3/lk3-study-s3
UPDATE rooms SET y = 430 WHERE id = 151; -- lk3/lk3-study-s4
UPDATE rooms SET y = 430 WHERE id = 152; -- lk3/teachers
UPDATE rooms SET y = 430 WHERE id = 153; -- lk3/wc-m
UPDATE rooms SET y = 430 WHERE id = 154; -- lk3/wc-f
UPDATE rooms SET y = 430 WHERE id = 155; -- lk3/lk3-study-s5
UPDATE rooms SET y = 430 WHERE id = 156; -- lk3/lk3-study-s6

-- uk1: равномерное распределение пустот между помещениями (ряд + входная группа)
UPDATE rooms SET x = 40  WHERE floor_id = 1 AND room_key = 'white';
UPDATE rooms SET x = 365 WHERE floor_id = 1 AND room_key = 'stolovaya';
UPDATE rooms SET x = 607 WHERE floor_id = 1 AND room_key = 'stairs-w';
UPDATE rooms SET x = 713 WHERE floor_id = 1 AND room_key = 'garderob';
UPDATE rooms SET x = 843 WHERE floor_id = 1 AND room_key = 'conf';
UPDATE rooms SET x = 990, w = 210 WHERE floor_id = 1 AND room_key = 'lib';
UPDATE rooms SET x = 551, y = 180 WHERE floor_id = 1 AND room_key = 'pass-lk';
UPDATE rooms SET x = 556 WHERE floor_id = 1 AND room_key = 'kiosk';
UPDATE rooms SET x = 588 WHERE floor_id = 1 AND room_key = 'entrance';
UPDATE rooms SET x = 663 WHERE floor_id = 1 AND room_key = 'ohrana';
