-- УК 1 этаж по макету заказчика (1 ЭТАЖ УК.pdf)
SET NAMES utf8mb4;
DELETE FROM rooms WHERE floor_id = 1;
INSERT INTO rooms (floor_id, room_key, name, type, row_index, row_y, row_height, weight, x, y, w, h, sort_order) VALUES
(1, 'conf', 'Конференц-зал', 'service', NULL, NULL, NULL, NULL, 40, 280, 225, 360, 1),
(1, 'stolovaya', 'Столовая', 'service', NULL, NULL, NULL, NULL, 280, 200, 200, 130, 2),
(1, 'stairs-w', 'Главная лестница', 'stairs', NULL, NULL, NULL, NULL, 492, 200, 60, 130, 3),
(1, 'pass-lk', 'Переход в лабораторный корпус', 'service', NULL, NULL, NULL, NULL, 750, 40, 70, 160, 4),
(1, 'kiosk', 'Киоск КТИТС-ИНФО', 'service', NULL, NULL, NULL, NULL, 660, 340, 60, 40, 5),
(1, 'garderob', 'Гардероб', 'service', NULL, NULL, NULL, NULL, 640, 430, 110, 90, 6),
(1, 'white', 'Зал совещаний', 'service', NULL, NULL, NULL, NULL, 800, 400, 120, 120, 7),
(1, 'lib', 'Библиотека', 'service', NULL, NULL, NULL, NULL, 950, 200, 250, 200, 8),
(1, 'entrance', 'Главный вход', 'service', NULL, NULL, NULL, NULL, 540, 480, 60, 80, 9),
(1, 'ohrana', 'Пост охраны', 'service', NULL, NULL, NULL, NULL, 610, 480, 60, 80, 10);
DELETE FROM route_nodes WHERE floor_id = 1;
DELETE FROM route_edges WHERE node_a IN (SELECT id FROM route_nodes WHERE floor_id = 1);
