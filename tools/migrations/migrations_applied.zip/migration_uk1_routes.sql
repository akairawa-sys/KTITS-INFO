-- Маршрутная сеть uk1 по макету: коридорная линия, вход, лестница, переход
SET NAMES utf8mb4;
INSERT INTO route_nodes (floor_id, x, y, kind, room_key) VALUES
(1, 340, 360, 'corridor', NULL),
(1, 480, 360, 'corridor', NULL),
(1, 620, 360, 'corridor', NULL),
(1, 740, 360, 'corridor', NULL),
(1, 860, 360, 'corridor', NULL),
(1, 980, 360, 'corridor', NULL),
(1, 1100, 360, 'corridor', NULL),
(1, 570, 520, 'entrance', 'entrance'),
(1, 522, 265, 'stairs', 'stairs-w'),
(1, 785, 120, 'passage', 'pass-lk'),
(1, 690, 360, 'corridor', 'kiosk');
INSERT INTO route_edges (node_a, node_b)
SELECT a.id, b.id FROM route_nodes a JOIN route_nodes b ON b.floor_id = a.floor_id
WHERE a.floor_id = 1 AND (
  (a.x = 340 AND a.y = 360 AND b.x = 480 AND b.y = 360) OR
  (a.x = 480 AND a.y = 360 AND b.x = 620 AND b.y = 360) OR
  (a.x = 620 AND a.y = 360 AND b.x = 690 AND b.y = 360) OR
  (a.x = 690 AND a.y = 360 AND b.x = 740 AND b.y = 360) OR
  (a.x = 740 AND a.y = 360 AND b.x = 860 AND b.y = 360) OR
  (a.x = 860 AND a.y = 360 AND b.x = 980 AND b.y = 360) OR
  (a.x = 980 AND a.y = 360 AND b.x = 1100 AND b.y = 360) OR
  (a.kind = 'entrance' AND b.x = 620 AND b.y = 360) OR
  (a.kind = 'stairs' AND b.x = 480 AND b.y = 360) OR
  (a.kind = 'passage' AND b.x = 740 AND b.y = 360)
);
