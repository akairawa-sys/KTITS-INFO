-- Спортзал: помещения по коридору, спортзал по высоте обеих рядов
SET NAMES utf8mb4;
UPDATE rooms SET x = 30, y = 210, w = 80, h = 300 WHERE floor_id = 5 AND room_key = 'pass-uk';
UPDATE rooms SET x = 122, y = 210, h = 100 WHERE floor_id = 5 AND room_key = 'trainers';
UPDATE rooms SET x = 314, y = 210, h = 100 WHERE floor_id = 5 AND room_key = 'vent';
UPDATE rooms SET x = 406, y = 210, h = 100 WHERE floor_id = 5 AND room_key = 'inventory';
UPDATE rooms SET x = 820, y = 210, w = 380, h = 300 WHERE floor_id = 5 AND room_key = 'sport';
