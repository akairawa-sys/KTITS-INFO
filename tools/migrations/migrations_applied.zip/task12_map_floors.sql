-- Задача 12: новая планировка 1 УК, санузлы на 1 ЛК, 2 ЛК в свободной планировке
SET NAMES utf8mb4;

-- 1 УК: планировка по описанию заказчика
-- вход по центру; справа охрана; киоск перед входом в большом холле;
-- левее входа главная лестница; слева холл -> столовая -> конференц-зал;
-- справа в холле гардероб; тёплый переход в ЛК справа от киоска;
-- справа второй холл -> белый зал -> библиотека
DELETE FROM rooms WHERE floor_id = 1;
INSERT INTO rooms (floor_id, room_key, name, type, row_index, row_y, row_height, weight, x, y, w, h, sort_order) VALUES
(1, 'conf', 'Конференц-зал', 'service', NULL, NULL, NULL, NULL, 40, 40, 270, 260, 1),
(1, 'stairs-w', 'Главная лестница', 'stairs', NULL, NULL, NULL, NULL, 330, 60, 100, 130, 2),
(1, 'white', 'Белый зал', 'service', NULL, NULL, NULL, NULL, 900, 60, 190, 200, 3),
(1, 'lib', 'Библиотека', 'service', NULL, NULL, NULL, NULL, 1100, 60, 100, 200, 4),
(1, 'kiosk', 'Киоск КТИТС-ИНФО', 'service', NULL, NULL, NULL, NULL, 560, 410, 120, 90, 5),
(1, 'ohrana', 'Пост охраны', 'service', NULL, NULL, NULL, NULL, 730, 500, 130, 110, 6),
(1, 'entrance', 'ВХОД', 'service', NULL, NULL, NULL, NULL, 530, 520, 180, 120, 7),
(1, 'garderob', 'Гардероб', 'service', NULL, NULL, NULL, NULL, 890, 520, 170, 120, 8),
(1, 'pass-lk', 'Тёплый переход в ЛК', 'service', NULL, NULL, NULL, NULL, 1090, 420, 110, 160, 9),
(1, 'stolovaya', 'Столовая', 'service', NULL, NULL, NULL, NULL, 40, 420, 290, 220, 10),
(1, 'wc', 'Санузел', 'service', NULL, NULL, NULL, NULL, 350, 420, 100, 120, 11);

-- 1 ЛК: мужской и женский туалеты рядом с лестницей
UPDATE rooms SET x = 930, w = 95 WHERE floor_id = 5 AND room_key = '1120';
UPDATE rooms SET x = 1035, w = 85 WHERE floor_id = 5 AND room_key = 'stairs-e';
INSERT INTO rooms (floor_id, room_key, name, type, row_index, row_y, row_height, weight, x, y, w, h, sort_order) VALUES
(5, 'wc-m', 'Мужской туалет', 'service', NULL, NULL, NULL, NULL, 1130, 60, 70, 120, 15),
(5, 'wc-f', 'Женский туалет', 'service', NULL, NULL, NULL, NULL, 1130, 190, 70, 130, 16);

-- 2 ЛК: перевод из «строчного» режима в свободную планировку
-- координаты повторяют раскладку движка (формула arrangedRooms в js/map.js)
UPDATE rooms SET row_index = NULL, row_y = NULL, row_height = NULL, weight = NULL, x = 40, y = 60, w = 96, h = 250 WHERE floor_id = 6 AND room_key = '1202';
UPDATE rooms SET row_index = NULL, row_y = NULL, row_height = NULL, weight = NULL, x = 148, y = 60, w = 96, h = 250 WHERE floor_id = 6 AND room_key = '1204';
UPDATE rooms SET row_index = NULL, row_y = NULL, row_height = NULL, weight = NULL, x = 256, y = 60, w = 97, h = 250 WHERE floor_id = 6 AND room_key = 'wc-f';
UPDATE rooms SET row_index = NULL, row_y = NULL, row_height = NULL, weight = NULL, x = 365, y = 60, w = 96, h = 250 WHERE floor_id = 6 AND room_key = 'wc-m';
UPDATE rooms SET row_index = NULL, row_y = NULL, row_height = NULL, weight = NULL, x = 473, y = 60, w = 96, h = 250 WHERE floor_id = 6 AND room_key = '1210';
UPDATE rooms SET row_index = NULL, row_y = NULL, row_height = NULL, weight = NULL, x = 581, y = 60, w = 97, h = 250 WHERE floor_id = 6 AND room_key = '1212';
UPDATE rooms SET row_index = NULL, row_y = NULL, row_height = NULL, weight = NULL, x = 690, y = 60, w = 96, h = 250 WHERE floor_id = 6 AND room_key = '1214';
UPDATE rooms SET row_index = NULL, row_y = NULL, row_height = NULL, weight = NULL, x = 798, y = 60, w = 96, h = 250 WHERE floor_id = 6 AND room_key = '1216';
UPDATE rooms SET row_index = NULL, row_y = NULL, row_height = NULL, weight = NULL, x = 906, y = 60, w = 97, h = 250 WHERE floor_id = 6 AND room_key = '1218';
UPDATE rooms SET row_index = NULL, row_y = NULL, row_height = NULL, weight = NULL, x = 1015, y = 60, w = 96, h = 250 WHERE floor_id = 6 AND room_key = '1220';
UPDATE rooms SET row_index = NULL, row_y = NULL, row_height = NULL, weight = NULL, x = 1123, y = 60, w = 77, h = 250 WHERE floor_id = 6 AND room_key = 'stairs-e';
UPDATE rooms SET row_index = NULL, row_y = NULL, row_height = NULL, weight = NULL, x = 40, y = 400, w = 109, h = 240 WHERE floor_id = 6 AND room_key = '1201';
UPDATE rooms SET row_index = NULL, row_y = NULL, row_height = NULL, weight = NULL, x = 161, y = 400, w = 109, h = 240 WHERE floor_id = 6 AND room_key = '1203';
UPDATE rooms SET row_index = NULL, row_y = NULL, row_height = NULL, weight = NULL, x = 282, y = 400, w = 93, h = 240 WHERE floor_id = 6 AND room_key = 'stairs-w';
UPDATE rooms SET row_index = NULL, row_y = NULL, row_height = NULL, weight = NULL, x = 387, y = 400, w = 207, h = 240 WHERE floor_id = 6 AND room_key = '1207-1209';
UPDATE rooms SET row_index = NULL, row_y = NULL, row_height = NULL, weight = NULL, x = 606, y = 400, w = 109, h = 240 WHERE floor_id = 6 AND room_key = '1211';
UPDATE rooms SET row_index = NULL, row_y = NULL, row_height = NULL, weight = NULL, x = 727, y = 400, w = 109, h = 240 WHERE floor_id = 6 AND room_key = '1213';
UPDATE rooms SET row_index = NULL, row_y = NULL, row_height = NULL, weight = NULL, x = 848, y = 400, w = 109, h = 240 WHERE floor_id = 6 AND room_key = '1215';
UPDATE rooms SET row_index = NULL, row_y = NULL, row_height = NULL, weight = NULL, x = 969, y = 400, w = 109, h = 240 WHERE floor_id = 6 AND room_key = '1217';
UPDATE rooms SET row_index = NULL, row_y = NULL, row_height = NULL, weight = NULL, x = 1090, y = 400, w = 109, h = 240 WHERE floor_id = 6 AND room_key = '1219';
